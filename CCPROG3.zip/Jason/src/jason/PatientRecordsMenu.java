/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jason;

import java.io.FileInputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Jason
 */
public class PatientRecordsMenu {

    private static String TABLE_FORMAT = "%-16s%-16s%-16s%-16s%-16s%-40s%-16s%-16s";
    private static String NUMBERED_TABLE_FORMAT = "%-4s%-16s%-16s%-16s%-16s%-16s%-40s%-16s%-16s";
    private static String PATIENT_FILE_NAME = "Patients.txt";
    private static ArrayList < PatientRecords > patients;

    public static void mainMenu() {
        readFile();
        displayMenu();
        transactionSelect();
    }

    public static void displayMenu() {
        System.out.println("\nManage Patient Records");
        System.out.println("[1] Add New Patient");
        System.out.println("[2] Edit New Patient");
        System.out.println("[3] Delete Patient Record");
        System.out.println("[4] Search Patient Record");
        System.out.println("[X] Return to Main Menu\n");
    }

    public static void transactionSelect() {
        boolean validInput = true;
        do {
            Scanner input = new Scanner(System.in);
            System.out.print("Select a transaction: ");
            try {
                String choice = input.nextLine();
                System.out.println();
                switch (choice) {
                case "1":
                    addRecord();
                    validInput = true;
                    break;
                case "2":
                    displayEditRecordMenu();
                    validInput = true;
                    break;
                case "3":
                    displayDeleteRecordMenu();
                    validInput = true;
                    break;
                case "4":
                    displaySearchRecordMenu();
                    validInput = true;
                    break;
                case "x":
                    Main.mainMenu();
                    validInput = true;
                    break;
                default:
                    throw new InputMismatchException();
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input, either choose from 1 to 4 or type x to go back.\n");
                validInput = false;
            }
        } while (validInput == false);
    }

    public static void writeToFile() {
        try (PrintWriter out = new PrintWriter(PATIENT_FILE_NAME)) {
            for (int i = 0; i < patients.size(); i++) {
                out.println(patients.get(i).toFormattedString());
                
            }
            out.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("File writing has failed.");
        }
    }

    public static void readFile() {
        patients = new ArrayList < PatientRecords > ();
        try (FileInputStream fis = new FileInputStream(PATIENT_FILE_NAME)) {
            while (fis.available() > 0) {
                String lName = readNextValue(fis);
                String fName = readNextValue(fis);
                String mName = readNextValue(fis);
                String bday = readNextValue(fis);
                char gender = readNextValue(fis).charAt(0);
                String address = readNextValue(fis);
                String phoneNum = readNextValue(fis);
                String nationalIDNum = readNextValue(fis);
                PatientRecords currentPatient = new PatientRecords(lName, fName, mName, bday, gender, address, phoneNum, nationalIDNum);
                patients.add(currentPatient);
                //System.out.println(patients.size()); FOR DEBUGGING
                //System.out.println(currentPatient.toDisplayString());
            }
            fis.close();
        } catch (Exception e) {
            String message = e.getMessage();
            if ("String index out of range: 0".equals(message)){
                System.out.println("File has been read.");
            }
            else {
                System.out.println(e.getMessage());
            }
            
        }
    }

    public static String readNextValue(FileInputStream fis) {
        StringBuilder sb = new StringBuilder();
        int i = 0;
        try {
            while ((i = fis.read()) != -1) {
                char currentChar = (char) i;
                if (currentChar != ';') {
                    sb.append(currentChar);
                } else {
                    break;
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return "";
        }
        return sb.toString();
    }

    public static void addRecord() {
        Scanner input = new Scanner(System.in);
        boolean validInput = true;
        char gender = '?';

        System.out.println("Add New Patient");
        System.out.print("First Name: ");
        String fName = input.nextLine();

        System.out.print("Last Name: ");
        String lName = input.nextLine();

        System.out.print("Middle Name: ");
        String mName = input.nextLine();

        System.out.print("Birthday (YYYYMMDD): ");
        String bday = input.nextLine();

        do {
            try {
                System.out.print("Gender (M/F): ");
                gender = Character.toUpperCase(input.next().charAt(0));
                switch (gender) {
                    case 'M': {
                        validInput = true;
                        break;
                    }
                    case 'F': {
                        validInput = true;
                        break;
                    }
                    default: {
                        throw new InputMismatchException();
                    }
                }
            } catch (InputMismatchException e) {
                System.out.println(gender);
                System.out.println("Invalid input, choose only M or F.\n");
                validInput = false;
            }
        } while (validInput == false);

        input.nextLine();
        System.out.print("Address: ");
        String address = input.nextLine();

        System.out.print("Phone Number: ");
        String phoneNum = input.nextLine();

        System.out.print("National ID Number: ");
        String nationalIDNum = input.nextLine();

        do {
            try {
                System.out.print("\nWould you like to save patient record? (Y/N): ");
                char addChoice = input.next().charAt(0);
                switch (addChoice) {
                case 'Y':
                case 'y': {
                    PatientRecords recordToAdd = new PatientRecords(lName, fName, mName, bday, gender, address, phoneNum, nationalIDNum);
                    System.out.println("\nNew Patient Records has been added, here is the record...");
                    System.out.println(recordToAdd.getLastName() + " " + recordToAdd.getFirstName() + " " + recordToAdd.getMiddleName() + " " + recordToAdd.getBirthday() + " " +
                        recordToAdd.getGender() + " " + recordToAdd.getAddress() + " " + recordToAdd.getPhoneNumber() + " " + recordToAdd.getNationalIDNumber());

                    patients.add(recordToAdd);
                    writeToFile();
                    validInput = true;
                    
                    do {
                        try {
                            System.out.print("\nWould you like to add another patient record? (Y/N): ");
                            char addAnotherChoice = input.next().charAt(0);
                            switch (addAnotherChoice) {
                            case 'Y':
                            case 'y': {
                                addRecord();
                                break;
                            }
                            case 'N':
                            case 'n': {
                                mainMenu();
                                break;
                            }
                            default: {
                                throw new InputMismatchException();
                            }
                            }
                        } catch (InputMismatchException e) {
                            System.out.println(gender);
                            System.out.println("Invalid input, choose only Y or N.\n");
                            validInput = false;
                        }
                    } while (validInput == false);
                    break;
                }
                case 'N':
                case 'n': {
                    displayMenu();
                    validInput = true;
                    break;
                }
                default:
                    throw new InputMismatchException();
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input, choose only Y or N.\n");
                validInput = false;
            }
        } while (validInput == false);
    }
    
    public static void displayEditRecordMenu() {
        System.out.println("Edit Patient Records ");
        System.out.println("Choose Patient Record to edit:  ");
        editRecordSelect();    
    }
    
    public static void editRecordSelect() {
        Scanner input = new Scanner(System.in);
        boolean validInput = true;
        if (patients.size() > 0) {
            System.out.println();
            System.out.format(NUMBERED_TABLE_FORMAT,"No.", "Last Name", "First Name", "Middle Name", "Birthday", "Gender", "Address", "Phone Number", "National ID no.");
            System.out.println();
            displayNumberedPatientList(patients);
            do {
                try {
                    System.out.print("\nWhich record would you like to edit? Choose the Number or type x to go back: ");
                    char recordEditChoice = input.next().charAt(0);
                    String choice = Character.toString(recordEditChoice);
                    if (recordEditChoice == 'x'){
                        mainMenu();
                        validInput = true;
                    }
                    else {
                        int index = Integer.parseInt(choice);
                        if (index < 0 || index >= patients.size()){
                            throw new Exception();
                        }
                        do {
                            System.out.print("\nWhat data would you like to edit? Address or Phone Number (A/P): ");
                            char dataEditChoice = Character.toUpperCase(input.next().charAt(0));
                            input.nextLine();
                            try {
                                switch (dataEditChoice){
                                    case 'A':{
                                        System.out.print("New Address: ");
                                        String newAddress = input.nextLine();
                                        patients.get(index).setAddress(newAddress);
                                        System.out.format("The Address/Phone number of patient #%d has been updated\n\n",index);
                                        writeToFile();
                                        validInput = true;
                                        break;
                                    }
                                    case 'P':{
                                        System.out.print("New Phone Number: ");
                                        String newPhoneNum = input.nextLine();
                                        patients.get(index).setPhoneNumber(newPhoneNum);
                                        System.out.format("The Address/Phone number of patient #%d has been updated\n\n",index);
                                        writeToFile();
                                        validInput = true;
                                        break;
                                    }
                                    default:{
                                        throw new InputMismatchException();
                                    }
                                }
                            } catch (InputMismatchException e){
                                System.out.println("Invalid input, choose only A or P. \n");
                                validInput = false;
                            }
                        } while (validInput == false);
                    }
                } catch (Exception e){
                    System.out.println("Invalid input, either choose from the numbers or type x to go back.\n");
                    editRecordSelect();
                }
            } while (validInput == false);
        } else {
            System.out.println("\nNo record found.");
            displayEditRecordMenu();
        }
    }

    public static void displayDeleteRecordMenu() {
        System.out.println("Delete Patient Records ");
        System.out.println("Choose Patient Record to delete:  ");
        deleteRecordSelect();    
    }
    
    public static void deleteRecordSelect() {
        Scanner input = new Scanner(System.in);
        boolean validInput = true;
        
       if (patients.size() > 0) {
            System.out.println();
            System.out.format(NUMBERED_TABLE_FORMAT,"No.", "Last Name", "First Name", "Middle Name", "Birthday", "Gender", "Address", "Phone Number", "National ID no.");
            System.out.println();
            displayNumberedPatientList(patients);
            
            do {
                try {
                    System.out.print("\nWhich record would you like to delete? Choose the Number or type x to go back: ");
                    char recordDeleteChoice = input.next().charAt(0);
                    String choice = Character.toString(recordDeleteChoice);
                    if (recordDeleteChoice == 'x'){
                        validInput = true;
                    }
                    else {
                        int index = Integer.parseInt(choice);
                        if (index < 0 || index >= patients.size()){
                            throw new Exception();
                        }
                        patients.remove(index);
                        System.out.format("Data of patient #%d has been deleted\n\n",index);
                        writeToFile();
                        validInput = true;
                    }
                } catch (Exception e){
                    System.out.println(e.getMessage());
                }
            } while (validInput == false);
        } else {
            System.out.println("\nNo record found.");
        }
    }
    
    public static void displaySearchRecordMenu() {
        System.out.println("Search Patient Records ");
        System.out.println("Choose Patient Record search method: ");
        System.out.println("[1] Last Name, First Name, Birthday ");
        System.out.println("[2] National ID Number ");
        System.out.println("[x] Back to Manage Patient Records Menu ");

        //displayPatientList(patients); FOR DEBUGGING
        
        searchRecordMenuMethodSelect();
    }
    
    public static void searchRecordMenuMethodSelect() {
        boolean validInput = true;
        do {
            Scanner input = new Scanner(System.in);
            System.out.print("\nSelect a method: ");
            try {
                String choice = input.nextLine();
                System.out.println();
                switch (choice) {
                case "1":
                    searchPatientsViaNameBirthdayCombinationMenu();
                    validInput = true;
                    break;
                case "2":
                    searchPatientsViaNationalIDNumberMenu();
                    validInput = true;
                    break;
                case "x":
                    PatientRecordsMenu.mainMenu();
                    validInput = true;
                    break;
                default:
                    throw new InputMismatchException();
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input, either choose from 1 to 2 or type x to go back.\n");
                validInput = false;
            }
        } while (validInput == false);
    }

    public static void searchPatientsViaNameBirthdayCombinationMenu() {
        Scanner input = new Scanner(System.in);
        boolean validInput = true;
        System.out.println("Search Patient Via Name and Birthday Combination");
        System.out.print("Last Name: ");
        String lName = input.nextLine();
        System.out.print("First Name: ");
        String fName = input.nextLine();
        System.out.print("Birthday (YYYYMMDD): ");
        String bday = input.nextLine();

        ArrayList < PatientRecords > patientResults = searchPatientsViaNameBirthdayCombination(lName, fName, bday);

        //int patLen = patients.size(); FOR DEBUGGING
        //int sepatLen = patientResults.size();
        //System.out.println("Here is patients length: " + patLen);
        //System.out.println("Here is searched patients length: " + sepatLen);
        
        if (patientResults.size() > 0) {
            System.out.println();
            System.out.format(NUMBERED_TABLE_FORMAT, "No", "Last Name", "First Name", "Middle Name", "Birthday", "Gender", "Address", "Phone Number", "National ID no.");
            System.out.println();

            displayNumberedPatientList(patientResults);
            
            do {
                try {
                    System.out.print("\nWhich record would you like to display? Choose the Number or type x to go back: ");
                    char recordDisplayChoice = input.next().charAt(0);
                    String choice = Character.toString(recordDisplayChoice);
                    if (recordDisplayChoice == 'x'){
                        validInput = true;
                        displaySearchRecordMenu();
                        searchRecordMenuMethodSelect();
                    }
                    else {
                        int index = Integer.parseInt(choice);
                        if (index < 0 || index >= patients.size()){
                            throw new Exception();
                        }
                        System.out.println("\nName: " + patients.get(index).getLastName() + ", " + patients.get(index).getFirstName() + " " + patients.get(index).getMiddleName());
                        System.out.println("Birthday: " + patients.get(index).getBirthday());
                        System.out.println("Address: " + patients.get(index).getAddress());
                        System.out.println("Phone Number: " + patients.get(index).getPhoneNumber());
                        System.out.format("%-30s%-30s%-30s", "Lab Test Type", "Request Date", "Result");
                        System.out.println();
                        System.out.format("%-30s%-30s%-30s", "XXXXXX", "XXXXXX", "XXXXXX");
                        validInput = true;
                    }
                } catch (Exception e){
                    System.out.println(e.getMessage());
                }
            } while (validInput == false);
        }
        else {
            System.out.println("\nNo record found.");
            searchPatientsViaNameBirthdayCombinationMenu();
        }
    }

    public static ArrayList < PatientRecords > searchPatientsViaNameBirthdayCombination(String lastNameQuery, String firstNameQuery, String birthdayQuery) {
        ArrayList < PatientRecords > patientSearchResults = new ArrayList < PatientRecords > ();
        int patLen = patients.size();
        System.out.println("Here is patients length: " + patLen);
        for (int i = 0; i < patients.size(); i++) {
            PatientRecords currentPatient = patients.get(i);
            System.out.println(currentPatient.getLastName() + " = " + lastNameQuery);
            System.out.println(currentPatient.getFirstName() + " = " + firstNameQuery);
            System.out.println(currentPatient.getBirthday() + " = " + birthdayQuery);
            if (currentPatient.getLastName().equalsIgnoreCase(lastNameQuery)) {
                System.out.println("Last Name Matched");
                if (currentPatient.getFirstName().equalsIgnoreCase(firstNameQuery)) {
                    System.out.println("First Name Matched");
                    if (currentPatient.getBirthday().equalsIgnoreCase(birthdayQuery)) {
                        System.out.println("Birthday Matched");
                        patientSearchResults.add(currentPatient);
                    }
                }
            }
        }
        return patientSearchResults;
    }

    public static void searchPatientsViaNationalIDNumberMenu() {
        Scanner input = new Scanner(System.in);
        System.out.println("Search Patient Via National ID Number");
        System.out.print("Input National ID Number: ");
        String nationalIDNum = input.nextLine();

        ArrayList < PatientRecords > patientResults = searchPatientsViaNationalIDNumber(nationalIDNum);

        if (patientResults.size() > 0) {
            System.out.println();
            System.out.format(TABLE_FORMAT, "Last Name", "First Name", "Middle Name", "Birthday", "Gender", "Address", "Phone Number", "National ID no.");
            System.out.println();

            for (int i = 0; i < patientResults.size(); i++) {
                System.out.println(patientResults.get(i).toAlignedString());
            }
        } else {
            System.out.println("\nNo record found.\n");
            displaySearchRecordMenu();
            searchRecordMenuMethodSelect();
        }
    }

    public static ArrayList < PatientRecords > searchPatientsViaNationalIDNumber(String nationalIDNum) {
        ArrayList < PatientRecords > patientResults = new ArrayList < PatientRecords > ();
        for (int i = 0; i < patients.size(); i++) {
            if (patients.get(i).getNationalIDNumber().equals(nationalIDNum)) {
                patientResults.add(patients.get(i));
            }
        }
        return patientResults;
    }

    public static void displayPatientList(ArrayList < PatientRecords > patientList) {
        for (int i = 0; i < patientList.size(); i++) {
            System.out.println(patientList.get(i).toAlignedString());
        }
    }
    
    public static void displayNumberedPatientList(ArrayList < PatientRecords > patientList) {
        for (int i = 0; i < patientList.size(); i++) {
            System.out.format("%-4s",("#"+Integer.toString(i)));
            System.out.println(patientList.get(i).toAlignedString());
        }
    }

}