/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jason;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Jason
 */
public class Main {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        mainMenu();
    }
    
    public static void mainMenu(){
        displayMenu();
        transactionSelect();
    }
    
    public static void displayMenu() {
        System.out.println("Medical Laboratory Information System");
        System.out.println("[1] Manage Patient Records");
        System.out.println("[2] Manage Services");
        System.out.println("[3] Manage Laboratory Results\n");
    }
    
    public static void transactionSelect(){
        boolean validInput = true;
        do {
            Scanner input = new Scanner(System.in);
            System.out.print("Select a transaction: ");
            try {
                int choice = input.nextInt();
                System.out.println();
                switch (choice){
                    case 1:
                        System.out.println();
                        PatientRecordsMenu.mainMenu();
                        validInput = true;
                        break;
                    case 2:
                        System.out.println("#2 works");
                        validInput = true;
                        break;
                    case 3:
                        System.out.println("#3 works");
                        validInput = true;
                        break;
                    default:
                        throw new InputMismatchException();
                }
            } catch (InputMismatchException e){
                System.out.println("Invalid input, choose from 1 to 3 only.\n");
                validInput = false;
            }
        } while (validInput == false);
    }   
}
