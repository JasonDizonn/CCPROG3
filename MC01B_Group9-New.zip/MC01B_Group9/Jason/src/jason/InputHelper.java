/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jason;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.Random;

/**
 *
 * @author Jason
 */
public class InputHelper implements Serializable {
    private static Scanner input = new Scanner(System.in);
    
    public static void initializeScanner(){
        input = new Scanner(System.in);
    }
    
    public static String getStringInput(String inputText) {
        System.out.print(inputText);
        String text = input.nextLine();
        return text;
    }

    public static char getCharInput(String inputText) {
        System.out.print(inputText);
        return Character.toUpperCase(input.next().charAt(0));
    }

    public static void nextLine() {
        input.nextLine();
        return;
    }

}