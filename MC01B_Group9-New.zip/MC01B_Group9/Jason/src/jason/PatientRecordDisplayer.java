/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jason;

import java.io.Serializable;
import java.util.ArrayList;


/**
 *
 * @author Jason
 */
public class PatientRecordDisplayer implements Serializable{

    public static void displayPatientList(ArrayList < PatientRecord > patientList) {
        for (int i = 0; i < patientList.size(); i++) {
            System.out.println(patientList.get(i).toAlignedString());
        }
    }
    
    public static void displayNumberedPatientList(ArrayList < PatientRecord > patientList) {
        for (int i = 0; i < patientList.size(); i++) {
            System.out.format("%-4s",("#"+Integer.toString(i)));
            System.out.println(patientList.get(i).toAlignedString());
        }
    }
}



