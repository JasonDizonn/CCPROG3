/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jason;

import static jason.ProjectConstants.PATIENT_FILE_NAME;
import java.io.FileInputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.ArrayList;


/**
 *
 * @author Jason
 */
public class PatientsFileManager implements Serializable{

    public static void savePatientsFile(ArrayList < PatientRecord> patientsList) {
        try (PrintWriter out = new PrintWriter(ProjectConstants.PATIENT_FILE_NAME)) {
            for (int i = 0; i < patientsList.size(); i++) {
                out.println(patientsList.get(i).toFormattedString());                
            }
            out.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("File writing has failed.");
        }
    }
    
    public static ArrayList < PatientRecord > getPatientsFile() {
        ArrayList < PatientRecord > patientsList = new ArrayList < PatientRecord > ();
        try (FileInputStream fis = new FileInputStream(PATIENT_FILE_NAME)) {
            while (fis.available() > 0) {
                String lName = readNextValue(fis);
                String fName = readNextValue(fis);
                String mName = readNextValue(fis);
                String bday = readNextValue(fis);
                char gender = readNextValue(fis).charAt(0);
                String address = readNextValue(fis);
                String phoneNum = readNextValue(fis);
                String nationalIDNum = readNextValue(fis);
                PatientRecord currentPatient = new PatientRecord(lName, fName, mName, bday, gender, address, phoneNum, nationalIDNum);
                patientsList.add(currentPatient);
            }
            fis.close();
        } catch (Exception e) {
            String message = e.getMessage();
            if ("String index out of range: 0".equals(message)){
                System.out.println("File has been read.");
                return patientsList;
            }
            else {
                System.out.println(e.getMessage());
                return new ArrayList < PatientRecord > ();
            }            
        } return new ArrayList < PatientRecord > ();
    }

    public static String readNextValue(FileInputStream fis) {
        StringBuilder sb = new StringBuilder();
        int i = 0;
        try {
            while ((i = fis.read()) != -1) {
                char currentChar = (char) i;
                if (currentChar != ';') {
                    sb.append(currentChar);
                } else {
                    break;
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return "";
        }
        return sb.toString();
    }
}



