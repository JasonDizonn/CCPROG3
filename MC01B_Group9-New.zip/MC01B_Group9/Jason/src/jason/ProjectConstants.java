/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jason;

/**
 *
 * @author Jason
 */
public class ProjectConstants {
    public static final String TABLE_FORMAT = "%-16s%-16s%-16s%-16s%-16s%-40s%-16s%-16s";
    public static final String NUMBERED_TABLE_FORMAT = "%-4s%-16s%-16s%-16s%-16s%-16s%-40s%-16s%-16s";    
    public static final String FORMAT_STRING = "%-16s%-16s%-16s%-16s%-16s%-40s%-16s%-16s";
    public static final String PATIENT_FILE_NAME = "Patients.txt";
}