/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jason;

import java.io.FileInputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Jason
 */
public class PatientRecordsMenuNew {
    private static
    Scanner input = new Scanner(System.in);

    public static void displayMenu() {
        System.out.println("\nManage Patient Records");
        System.out.println("[1] Add New Patient");
        System.out.println("[2] Edit New Patient");
        System.out.println("[3] Delete Patient Record");
        System.out.println("[4] Search Patient Record");
        System.out.println("[X] Return to Main Menu\n");
        transactionSelect();
    }

    private static void transactionSelect() {
        char choice = InputHelper.getCharInput("Select a transaction: ");
        System.out.println();
        switch (choice) {
        case '1':
            AddRecordMenu.displayMenu();
            displayMenu();
            break;
        case '2':
            EditRecordMenu.displayMenu();
            displayMenu();
            break;
        case '3':
            DeleteRecordMenu.displayMenu();
            displayMenu();
            break;
        case '4':
            SearchRecordMenu.displayMenu();
            displayMenu();
            break;
        case 'X':
            MainMenu.displayMenu();
            return;
        default:
            System.out.println("Invalid input, either choose from 1 to 4 or type x to go back.\n");
        }
    }
}