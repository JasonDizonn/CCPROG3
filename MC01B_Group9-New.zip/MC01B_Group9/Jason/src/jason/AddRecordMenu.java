/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jason;

import static jason.InputHelper.getCharInput;
import java.util.ArrayList;
import java.util.InputMismatchException;

/**
 *
 * @author Jason
 */

public class AddRecordMenu {
    private static ArrayList < PatientRecord > patientsList;

    public static void displayMenu() {
        InputHelper.initializeScanner();
        
        System.out.println("Add New Patient");

        String fName = InputHelper.getStringInput("First Name: ");
        String lName = InputHelper.getStringInput("Last Name: ");
        String mName = InputHelper.getStringInput("Middle Name: ");
        String bday = InputHelper.getStringInput("Birthday (YYYYMMDD): ");
        char gender = getGenderInput();

        InputHelper.nextLine();

        String address = InputHelper.getStringInput("Address");
        String phoneNum = InputHelper.getStringInput("Phone Number");
        String nationalIDNum = InputHelper.getStringInput("National ID Number: ");

        PatientRecord recordToAdd = new PatientRecord(lName, fName, mName, bday, gender, address, phoneNum, nationalIDNum);

        displaySaveRecordMenu(recordToAdd);
    }

    private static char getGenderInput() {
        char gender = InputHelper.getCharInput("Gender (M/F): ");
        if (gender != 'M' && gender != 'F') {
            System.out.println("Invalid input, choose only M or F.\n");
            return getGenderInput();
        } else {
            return gender;
        }
    }

    private static void displaySaveRecordMenu(PatientRecord recordToAdd) throws InputMismatchException {
        char addChoice = InputHelper.getCharInput("\nWould you like to save patient record? (Y/N): ");
        switch (addChoice) {
        case 'Y':
            addPatientToRecords(recordToAdd);
            displayAddAnotherPatientMenu();
            break;
        case 'N':
            return;
        default:
            displaySaveRecordMenu(recordToAdd);
            break;
        }
    }

    private static void addPatientToRecords(PatientRecord recordToAdd) {
        patientsList = PatientsFileManager.getPatientsFile();
        patientsList.add(recordToAdd);
        System.out.println("\nNew Patient Records has been added, here is the record...");
        System.out.println(recordToAdd.toDisplayString());
        PatientsFileManager.savePatientsFile(patientsList);
    }

    private static void displayAddAnotherPatientMenu() {
        char addAnotherChoice = getCharInput("\nWould you like to add another patient record? (Y/N): ");
        switch (addAnotherChoice) {
        case 'Y':
            AddRecordMenu.displayMenu();
            break;
        case 'N':
            return;
        default:
            displayAddAnotherPatientMenu();
            break;
        }
    }
}