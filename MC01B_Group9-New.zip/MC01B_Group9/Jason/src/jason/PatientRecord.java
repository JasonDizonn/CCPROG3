/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jason;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.Random;


/**
 *
 * @author Jason
 */
public class PatientRecord implements Serializable{
    private String lastName;
    private String firstName;
    private String middleName;
    private String birthday;
    private char gender;
    private String address;
    private String phoneNumber;
    private String nationalIDNumber;

    public PatientRecord(String lastName, String firstName, String middleName, String birthday, char gender, String address, String phoneNumber, String nationalIDNumber){
        this.lastName = lastName.trim();
        this.firstName = firstName.trim();
        this.middleName = middleName.trim();
        this.birthday = birthday.trim();
        this.gender = gender;
        this.address = address.trim();
        this.phoneNumber = phoneNumber.trim();
        this.nationalIDNumber = nationalIDNumber.trim();
    }
    
    public String toFormattedString(){
        String output = 
                lastName.trim() + ";" + 
                firstName.trim() + ";" + 
                middleName.trim() + ";" + 
                birthday.trim() + ";" + 
                gender + ";" + 
                address.trim() + ";" + 
                phoneNumber.trim() + ";" + 
                nationalIDNumber.trim() + ";";
        return output;
    }
    
    public String toDisplayString(){
        String output =
                lastName + " " + 
                firstName + " " +
                middleName + " " + 
                birthday + " " + 
                gender + " " + 
                address + " " + 
                phoneNumber + " " + 
                nationalIDNumber;
        return output;
    }
    
    public String toAlignedString(){
       String output = String.format(ProjectConstants.FORMAT_STRING,
               getTruncatedString(lastName.trim(),16), 
               getTruncatedString(firstName.trim(),16), 
               getTruncatedString(middleName.trim(),16), 
               getTruncatedString(birthday.trim(),16), 
               gender, 
               getTruncatedString(address.trim(),40), 
               getTruncatedString(phoneNumber.trim(),16), 
               getTruncatedString(nationalIDNumber.trim(),16));
       return output;
    }
    
    public String getTruncatedString(String string, int maxLength){
        if(string.length() <= maxLength){
            return string;
        }else{
            return string.substring(0,maxLength-4)+"...";
        }
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public char getGender() {
        return gender;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNo) {
        this.phoneNumber = phoneNo;
    }

    public String getNationalIDNumber() {
        return nationalIDNumber;
    }

    public void setNationalIDNumber(String nationalIDNo) {
        this.nationalIDNumber = nationalIDNo;
    }
}



