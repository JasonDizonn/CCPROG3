/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jason;

import static jason.ProjectConstants.NUMBERED_TABLE_FORMAT;
import static jason.ProjectConstants.TABLE_FORMAT;
import java.util.ArrayList;

/**
 *
 * @author Jason
 */
public class SearchRecordMenu {
    private static ArrayList < PatientRecord > patientsList;

    public static void displayMenu() {
        InputHelper.initializeScanner();
        patientsList = PatientsFileManager.getPatientsFile();
        System.out.println("Search Patient Records ");
        System.out.println("Choose Patient Record search method: ");
        System.out.println("[1] Last Name, First Name, Birthday ");
        System.out.println("[2] National ID Number ");
        System.out.println("[x] Back to Manage Patient Records Menu ");
        displaySelectSearchMethodMenu();
    }

    private static void displaySelectSearchMethodMenu() {
        char choice = InputHelper.getCharInput("\nSelect a method: ");
        System.out.println();
        switch (choice) {
        case '1':
            displaySearchViaNameBirthdayCombinationMenu();
            break;
        case '2':
            displaySearchViaNationalIDNumberMenu();
            break;
        case 'X':
            return;
        default:
            System.out.println("Invalid input, either choose from 1 to 2 or type x to go back.\n");
            displaySelectSearchMethodMenu();
            break;
        }
    }

    public static void displaySearchViaNameBirthdayCombinationMenu() {
        InputHelper.initializeScanner();
        System.out.println("Search Patient Via Name and Birthday Combination");
        String lName = InputHelper.getStringInput("Last Name: ");
        String fName = InputHelper.getStringInput("First Name: ");
        String bday = InputHelper.getStringInput("Birthday (YYYYMMDD): ");

        ArrayList < PatientRecord > patientResults = searchPatientsViaNameBirthdayCombination(lName, fName, bday);

        if (patientResults.size() <= 0) {
            System.out.println("\nNo record found.");
            displaySearchViaNameBirthdayCombinationMenu();
            return;
        }

        System.out.println();
        System.out.format(NUMBERED_TABLE_FORMAT, "No", "Last Name", "First Name", "Middle Name", "Birthday", "Gender", "Address", "Phone Number", "National ID no.");
        System.out.println();

        PatientRecordDisplayer.displayNumberedPatientList(patientResults);
        displayRecordSelectMenu(patientResults);
    }

    public static void displaySearchViaNationalIDNumberMenu() {
        System.out.println("Search Patient Via National ID Number");
        String nationalIDNum = InputHelper.getStringInput("Input National ID Number: ");
        ArrayList < PatientRecord > patientResults = searchPatientsViaNationalIDNumber(nationalIDNum);

        if (patientResults.size() <= 0) {
            System.out.println("\nNo record found.");
            displaySearchViaNationalIDNumberMenu();
            return;
        }

        System.out.println();
        System.out.format(TABLE_FORMAT, "Last Name", "First Name", "Middle Name", "Birthday", "Gender", "Address", "Phone Number", "National ID no.");
        System.out.println();

        displayRecordSelectMenu(patientResults);
    }

    private static ArrayList < PatientRecord > searchPatientsViaNameBirthdayCombination(String lastNameQuery, String firstNameQuery, String birthdayQuery) {
        ArrayList < PatientRecord > patientResults = new ArrayList < PatientRecord > ();
        for (int i = 0; i < patientsList.size(); i++) {
            PatientRecord currentPatient = patientsList.get(i);
            System.out.println(currentPatient.getLastName() + " = " + lastNameQuery);
            System.out.println(currentPatient.getFirstName() + " = " + firstNameQuery);
            System.out.println(currentPatient.getBirthday() + " = " + birthdayQuery);
            if (currentPatient.getLastName().equalsIgnoreCase(lastNameQuery)) {
                System.out.println("Last Name Matched");
                if (currentPatient.getFirstName().equalsIgnoreCase(firstNameQuery)) {
                    System.out.println("First Name Matched");
                    if (currentPatient.getBirthday().equalsIgnoreCase(birthdayQuery)) {
                        System.out.println("Birthday Matched");
                        patientResults.add(currentPatient);
                    }
                }
            }
        }
        return patientResults;
    }

    private static ArrayList < PatientRecord > searchPatientsViaNationalIDNumber(String nationalIDNum) {
        ArrayList < PatientRecord > patientResults = new ArrayList < PatientRecord > ();
        for (int i = 0; i < patientsList.size(); i++) {
            if (patientsList.get(i).getNationalIDNumber().equals(nationalIDNum)) {
                patientResults.add(patientsList.get(i));
            }
        }
        return patientResults;
    }

    private static void displayRecordSelectMenu(ArrayList < PatientRecord > recordSelectList) {
        char recordDisplayChoice = InputHelper.getCharInput("\nWhich record would you like to display? Choose the Number or type x to go back: ");
        if (recordDisplayChoice == 'x') {
            displayMenu();
            return;
        }
        int selectedIndex = Integer.parseInt(Character.toString(recordDisplayChoice));
        if (selectedIndex < 0 || selectedIndex >= recordSelectList.size()) {
            System.out.println("Invalid input, either choose from the numbers or type x to go back.\n");
            displayRecordSelectMenu(recordSelectList);
            return;
        }
        displayRecordData(recordSelectList.get(selectedIndex));
    }

    private static void displayRecordData(PatientRecord selectedRecord) {
        System.out.println("\nName: " + selectedRecord.getLastName() + ", " + selectedRecord.getFirstName() + " " + selectedRecord.getMiddleName());
        System.out.println("Birthday: " + selectedRecord.getBirthday());
        System.out.println("Address: " + selectedRecord.getAddress());
        System.out.println("Phone Number: " + selectedRecord.getPhoneNumber());
        System.out.format("%-30s%-30s%-30s", "Lab Test Type", "Request Date", "Result");
        System.out.println();
        System.out.format("%-30s%-30s%-30s", "XXXXXX", "XXXXXX", "XXXXXX");
    }
}