/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jason;

import java.io.FileInputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Jason
 */
public class EditRecordMenu {
    private static ArrayList < PatientRecord > patientsList;

    public static void displayMenu() {
        InputHelper.initializeScanner();
        patientsList = PatientsFileManager.getPatientsFile();
        System.out.println("Edit Patient Records ");
        System.out.println("Choose Patient Record to edit:  ");
        System.out.println();

        if (patientsList.size() <= 0) {
            System.out.println("\nNo record found.");
            return;
        }

        System.out.format(ProjectConstants.NUMBERED_TABLE_FORMAT, "No.", "Last Name", "First Name", "Middle Name", "Birthday", "Gender", "Address", "Phone Number", "National ID no.");
        System.out.println();
        PatientRecordDisplayer.displayNumberedPatientList(patientsList);

        displayRecordSelectMenu();
    }

    private static void displayRecordSelectMenu() {
        char recordEditChoice = InputHelper.getCharInput("\nWhich record would you like to edit? Choose the Number or type x to go back: ");

        if (recordEditChoice == 'X') {
            return;
        }

        int selectedIndex = Integer.parseInt(Character.toString(recordEditChoice));
        if (selectedIndex < 0 || selectedIndex >= patientsList.size()) {
            System.out.println("Invalid input, either choose from the numbers or type x to go back.\n");
            displayRecordSelectMenu();
            return;
        }
        displayEditMenu(selectedIndex);
    }

    private static void displayEditMenu(int selectedIndex) {
        char dataEditChoice = InputHelper.getCharInput("\nWhat data would you like to edit? Address or Phone Number (A/P): ");
        InputHelper.nextLine();

        switch (dataEditChoice) {
        case 'A':
            String newAddress = InputHelper.getStringInput("New Address: ");
            patientsList.get(selectedIndex).setAddress(newAddress);
            System.out.format("The Address/Phone number of patient #%d has been updated\n\n", selectedIndex);
            PatientsFileManager.savePatientsFile(patientsList);
            break;
        case 'P':
            String newPhoneNum = InputHelper.getStringInput("New Phone Number: ");
            patientsList.get(selectedIndex).setPhoneNumber(newPhoneNum);
            System.out.format("The Address/Phone number of patient #%d has been updated\n\n", selectedIndex);
            PatientsFileManager.savePatientsFile(patientsList);
            break;
        default:
            System.out.println("Invalid input, choose only A or P. \n");
            displayEditMenu(selectedIndex);
            break;
        }
    }
}