/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jason;


import java.util.ArrayList;

/**
 *
 * @author Jason
 */
public class DeleteRecordMenu {
    private static ArrayList < PatientRecord > patientsList;

    public static void displayMenu() {        
        patientsList = PatientsFileManager.getPatientsFile();
        System.out.println("Delete Patient Records ");
        System.out.println("Choose Patient Record to delete:  ");
        System.out.println();

        if (patientsList.size() <= 0) {
            System.out.println("\nNo record found.");
            return;
        }

        System.out.format(ProjectConstants.NUMBERED_TABLE_FORMAT, "No.", "Last Name", "First Name", "Middle Name", "Birthday", "Gender", "Address", "Phone Number", "National ID no.");
        System.out.println();
        PatientRecordDisplayer.displayNumberedPatientList(patientsList);

        displayRecordSelectMenu();
    }

    private static void displayRecordSelectMenu() {
        char recordDeleteChoice = InputHelper.getCharInput("\nWhich record would you like to delete? Choose the Number or type x to go back: ");

        if (recordDeleteChoice == 'X') {
            return;
        }

        int selectedIndex = Integer.parseInt(Character.toString(recordDeleteChoice));
        if (selectedIndex < 0 || selectedIndex >= patientsList.size()) {
            System.out.println("Invalid input, either choose from the numbers or type x to go back.\n");
            displayRecordSelectMenu();
            return;
        } else {
            deletePatientAtIndex(selectedIndex);
        }
    }

    private static void deletePatientAtIndex(int selectedIndex) {
        patientsList.remove(selectedIndex);
        System.out.format("Data of patient #%d has been deleted\n\n", selectedIndex);
        PatientsFileManager.savePatientsFile(patientsList);
    }
}