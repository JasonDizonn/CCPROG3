package jason;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Jason
 */

public class MainMenu {
    private static Scanner input = new Scanner(System.in);

    public static void main(String[] args) {
        displayMenu();
    }

    public static void displayMenu() {
        System.out.println("Medical Laboratory Information System");
        System.out.println("[1] Manage Patient Records");
        System.out.println("[2] Manage Services");
        System.out.println("[3] Manage Laboratory Results\n");
        transactionSelect();
    }

    public static void transactionSelect() {
        int choice = InputHelper.getCharInput("Select a transaction: ");
        System.out.println();
        switch (choice) {
        case '1':
            System.out.println();
            PatientRecordsMenuNew.displayMenu();
            break;
        case '2':
            System.out.println("#2 works");
            break;
        case '3':
            System.out.println("#3 works");
            break;
        default:
            System.out.println("Invalid input, choose from 1 to 3 only.\n");
            transactionSelect();
            break;
        }
    }
}